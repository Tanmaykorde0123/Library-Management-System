# Library Management System

This project is a full-stack library management system with a Python backend (Flask) and a modern HTML/JS frontend. It supports both MySQL-backed and in-memory operation.

## Features
- Add, search, and delete books
- Add and list members
- Borrow and return books
- Dashboard and reports

## Setup & Run

1. **Install Python dependencies**

```powershell
python -m pip install -r requirements.txt
```

2. **Set up the MySQL database** (optional, for persistent storage)

- Create a database named `library_management` and run the SQL in `schema.sql`.
- Update the credentials in `lib.py` if needed.

3. **Run the Flask server**

```powershell
python app.py
```

4. **Open the frontend**

- Open `lib.html` in your browser (double-click or use VS Code Live Server).
- The frontend will connect to the backend at `http://127.0.0.1:5000`.

## API Endpoints
- `GET /api/dashboard` — summary stats
- `GET/POST /api/books` — list/add books
- `POST /api/books/delete` — delete book
- `GET/POST /api/members` — list/add members
- `GET /api/borrowings` — list borrowings
- `POST /api/borrow` — borrow book
- `POST /api/return` — return book

## Fallback Mode
If MySQL is not available, the backend will use an in-memory store (no persistence).

## Database Schema
See `schema.sql` for the required tables.

---

## SQL DDL Example
See `schema.sql` for the full schema.

import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta

class LibraryManagement:
    def __init__(self):
        self.connection = self.create_connection()
        
    def create_connection(self):
        """Create database connection"""
        try:
            connection = mysql.connector.connect(
                host='localhost',
                user='root',  # Change to your MySQL username
                password='root@123',  # Change to your MySQL password
                database='library_management'
            )
            if connection.is_connected():
                print("Connected to MySQL database")
                return connection
        except Error as e:
            print(f"Error: {e}")
            return None
    
    def close_connection(self):
        """Close database connection"""
        if self.connection and self.connection.is_connected():
            self.connection.close()
            print("Database connection closed")
    
    # Book Management
    def add_book(self, title, author, isbn, publication_year, genre, total_copies):
        """Add a new book to the library"""
        try:
            cursor = self.connection.cursor()
            query = """
            INSERT INTO books (title, author, isbn, publication_year, genre, total_copies, available_copies)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            values = (title, author, isbn, publication_year, genre, total_copies, total_copies)
            cursor.execute(query, values)
            self.connection.commit()
            print(f"Book '{title}' added successfully!")
        except Error as e:
            print(f"Error adding book: {e}")
    
    def search_books(self, search_term):
        """Search books by title, author, or ISBN"""
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
            SELECT * FROM books 
            WHERE title LIKE %s OR author LIKE %s OR isbn LIKE %s
            """
            search_pattern = f"%{search_term}%"
            cursor.execute(query, (search_pattern, search_pattern, search_pattern))
            books = cursor.fetchall()
            return books
        except Error as e:
            print(f"Error searching books: {e}")
            return []
    
    def display_all_books(self):
        """Display all books in the library"""
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM books")
            books = cursor.fetchall()
            return books
        except Error as e:
            print(f"Error fetching books: {e}")
            return []
    
    # Member Management
    def add_member(self, name, email, phone, address):
        """Add a new library member"""
        try:
            cursor = self.connection.cursor()
            query = """
            INSERT INTO members (name, email, phone, address, membership_date)
            VALUES (%s, %s, %s, %s, %s)
            """
            values = (name, email, phone, address, datetime.now().date())
            cursor.execute(query, values)
            self.connection.commit()
            print(f"Member '{name}' added successfully!")
        except Error as e:
            print(f"Error adding member: {e}")
    
    def display_all_members(self):
        """Display all library members"""
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM members")
            members = cursor.fetchall()
            return members
        except Error as e:
            print(f"Error fetching members: {e}")
            return []
    
    # Borrowing Management
    def borrow_book(self, book_id, member_id, days=14):
        """Borrow a book for a member"""
        try:
            cursor = self.connection.cursor()
            
            # Check if book is available
            cursor.execute("SELECT available_copies FROM books WHERE book_id = %s", (book_id,))
            result = cursor.fetchone()
            
            if not result or result[0] <= 0:
                print("Book is not available for borrowing")
                return False
            
            borrow_date = datetime.now().date()
            due_date = borrow_date + timedelta(days=days)
            
            # Insert borrowing record
            query = """
            INSERT INTO borrowings (book_id, member_id, borrow_date, due_date, status)
            VALUES (%s, %s, %s, %s, 'borrowed')
            """
            cursor.execute(query, (book_id, member_id, borrow_date, due_date))
            
            # Update available copies
            cursor.execute("UPDATE books SET available_copies = available_copies - 1 WHERE book_id = %s", (book_id,))
            
            self.connection.commit()
            print(f"Book borrowed successfully! Due date: {due_date}")
            return True
            
        except Error as e:
            print(f"Error borrowing book: {e}")
            return False
    
    def return_book(self, borrowing_id):
        """Return a borrowed book"""
        try:
            cursor = self.connection.cursor()
            
            # Get book_id from borrowing record
            cursor.execute("SELECT book_id FROM borrowings WHERE borrowing_id = %s", (borrowing_id,))
            result = cursor.fetchone()
            
            if not result:
                print("Borrowing record not found")
                return False
            
            book_id = result[0]
            return_date = datetime.now().date()
            
            # Update borrowing record
            cursor.execute("""
            UPDATE borrowings 
            SET return_date = %s, status = 'returned' 
            WHERE borrowing_id = %s
            """, (return_date, borrowing_id))
            
            # Update available copies
            cursor.execute("UPDATE books SET available_copies = available_copies + 1 WHERE book_id = %s", (book_id,))
            
            self.connection.commit()
            print("Book returned successfully!")
            return True
            
        except Error as e:
            print(f"Error returning book: {e}")
            return False
    
    def display_current_borrowings(self):
        """Display all current borrowings"""
        try:
            cursor = self.connection.cursor(dictionary=True)
            query = """
            SELECT b.borrowing_id, bk.title, m.name, b.borrow_date, b.due_date, b.status
            FROM borrowings b
            JOIN books bk ON b.book_id = bk.book_id
            JOIN members m ON b.member_id = m.member_id
            WHERE b.status = 'borrowed'
            """
            cursor.execute(query)
            borrowings = cursor.fetchall()
            return borrowings
        except Error as e:
            print(f"Error fetching borrowings: {e}")
            return []

# Main menu interface
def main():
    library = LibraryManagement()
    
    while True:
        print("\n=== Library Management System ===")
        print("1. Add Book")
        print("2. Search Books")
        print("3. Display All Books")
        print("4. Add Member")
        print("5. Display All Members")
        print("6. Borrow Book")
        print("7. Return Book")
        print("8. Display Current Borrowings")
        print("9. Exit")
        
        choice = input("Enter your choice (1-9): ")
        
        if choice == '1':
            print("\n--- Add New Book ---")
            title = input("Enter book title: ")
            author = input("Enter author: ")
            isbn = input("Enter ISBN: ")
            year = int(input("Enter publication year: "))
            genre = input("Enter genre: ")
            copies = int(input("Enter total copies: "))
            library.add_book(title, author, isbn, year, genre, copies)
            
        elif choice == '2':
            print("\n--- Search Books ---")
            search_term = input("Enter search term (title, author, or ISBN): ")
            books = library.search_books(search_term)
            if books:
                for book in books:
                    print(f"ID: {book['book_id']}, Title: {book['title']}, Author: {book['author']}, "
                          f"Available: {book['available_copies']}/{book['total_copies']}")
            else:
                print("No books found.")
                
        elif choice == '3':
            print("\n--- All Books ---")
            books = library.display_all_books()
            for book in books:
                print(f"ID: {book['book_id']}, Title: {book['title']}, Author: {book['author']}, "
                      f"ISBN: {book['isbn']}, Available: {book['available_copies']}/{book['total_copies']}")
                
        elif choice == '4':
            print("\n--- Add New Member ---")
            name = input("Enter member name: ")
            email = input("Enter email: ")
            phone = input("Enter phone: ")
            address = input("Enter address: ")
            library.add_member(name, email, phone, address)
            
        elif choice == '5':
            print("\n--- All Members ---")
            members = library.display_all_members()
            for member in members:
                print(f"ID: {member['member_id']}, Name: {member['name']}, Email: {member['email']}")
                
        elif choice == '6':
            print("\n--- Borrow Book ---")
            book_id = int(input("Enter book ID: "))
            member_id = int(input("Enter member ID: "))
            library.borrow_book(book_id, member_id)
            
        elif choice == '7':
            print("\n--- Return Book ---")
            borrowing_id = int(input("Enter borrowing ID: "))
            library.return_book(borrowing_id)
            
        elif choice == '8':
            print("\n--- Current Borrowings ---")
            borrowings = library.display_current_borrowings()
            if borrowings:
                for borrow in borrowings:
                    print(f"Borrow ID: {borrow['borrowing_id']}, Book: {borrow['title']}, "
                          f"Member: {borrow['name']}, Due: {borrow['due_date']}")
            else:
                print("No current borrowings.")
                
        elif choice == '9':
            print("Goodbye!")
            library.close_connection()
            break
            
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

from flask import Flask, request, jsonify, send_from_directory
import os
import traceback
try:
    try:
        from flask_cors import CORS
    except ImportError:
        def CORS(app):
            pass
except ImportError:
    def CORS(app):
        pass

app = Flask(__name__)
CORS(app)

# Try to import user's LibraryManagement; if DB unavailable, fall back to in-memory manager
try:
    from lib import LibraryManagement
except Exception:
    LibraryManagement = None

class InMemoryManager:
    def __init__(self):
        self._book_id = 3
        self._member_id = 2
        self._borrow_id = 0
        self.books = [
            { 'book_id': 1, 'title': 'The Great Gatsby', 'author': 'F. Scott Fitzgerald', 'isbn': '978-0-7432-7356-5', 'publication_year': 1925, 'genre': 'Fiction', 'total_copies': 3, 'available_copies': 3 },
            { 'book_id': 2, 'title': 'To Kill a Mockingbird', 'author': 'Harper Lee', 'isbn': '978-0-06-112008-4', 'publication_year': 1960, 'genre': 'Fiction', 'total_copies': 2, 'available_copies': 2 },
            { 'book_id': 3, 'title': '1984', 'author': 'George Orwell', 'isbn': '978-0-452-28423-4', 'publication_year': 1949, 'genre': 'Dystopian', 'total_copies': 4, 'available_copies': 4 },
        ]
        self.members = [
            { 'member_id': 1, 'name': 'John Smith', 'email': 'john.smith@email.com', 'phone': '555-0101', 'address': '123 Main St', 'membership_date': '2024-01-15' },
            { 'member_id': 2, 'name': 'Alice Johnson', 'email': 'alice.johnson@email.com', 'phone': '555-0102', 'address': '456 Oak Ave', 'membership_date': '2024-02-20' }
        ]
        self.borrowings = []

    def add_book(self, title, author, isbn, publication_year, genre, total_copies):
        self._book_id += 1
        b = {
            'book_id': self._book_id,
            'title': title,
            'author': author,
            'isbn': isbn,
            'publication_year': publication_year,
            'genre': genre,
            'total_copies': total_copies,
            'available_copies': total_copies
        }
        self.books.append(b)
        return True

    def display_all_books(self):
        return self.books

    def search_books(self, search_term):
        s = search_term.lower()
        return [b for b in self.books if s in b.get('title','').lower() or s in b.get('author','').lower() or s in b.get('isbn','')]

    def add_member(self, name, email, phone, address):
        self._member_id += 1
        m = { 'member_id': self._member_id, 'name': name, 'email': email, 'phone': phone, 'address': address, 'membership_date': None }
        self.members.append(m)
        return True

    def display_all_members(self):
        return self.members

    def borrow_book(self, book_id, member_id, days=14):
        book = next((b for b in self.books if b['book_id'] == book_id), None)
        member = next((m for m in self.members if m['member_id'] == member_id), None)
        if not book or not member: return False, 'Book or member not found'
        if book['available_copies'] <= 0: return False, 'No available copies'
        self._borrow_id += 1
        from datetime import date, timedelta
        borrow_date = date.today()
        due_date = borrow_date + timedelta(days=days)
        rec = { 'borrowing_id': self._borrow_id, 'book_id': book_id, 'member_id': member_id, 'borrow_date': borrow_date.isoformat(), 'due_date': due_date.isoformat(), 'status': 'borrowed', 'title': book['title'], 'name': member['name'] }
        self.borrowings.append(rec)
        book['available_copies'] -= 1
        return True, 'Borrowed successfully'

    def return_book(self, borrowing_id):
        idx = next((i for i,r in enumerate(self.borrowings) if r['borrowing_id'] == borrowing_id), None)
        if idx is None: return False
        rec = self.borrowings.pop(idx)
        if (book := next((b for b in self.books if b['book_id'] == rec['book_id']), None)):
            book['available_copies'] += 1
        return True

    def display_current_borrowings(self):
        return self.borrowings

manager = InMemoryManager()
print('Using InMemoryManager (DB always bypassed)')

@app.route('/api/dashboard')
def dashboard():
    try:
        books = manager.display_all_books()
        members = manager.display_all_members()
        borrows = manager.display_current_borrowings()
        totalBooks = len(books)
        totalMembers = len(members)
        borrowedBooks = len(borrows)
        availableCopies = sum((b.get('available_copies') or 0) for b in books)
        return jsonify({ 'totalBooks': totalBooks, 'totalMembers': totalMembers, 'borrowedBooks': borrowedBooks, 'availableCopies': availableCopies, 'overdueBooks': 0 })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/books', methods=['GET','POST'])
def books_endpoint():
    try:
        if request.method == 'GET':
            search = request.args.get('search')
            if search:
                return jsonify(manager.search_books(search))
            return jsonify(manager.display_all_books())
        data = request.get_json()
        manager.add_book(data.get('title'), data.get('author'), data.get('isbn'), data.get('publication_year'), data.get('genre'), data.get('total_copies'))
        return jsonify({'success': True, 'message': 'Book added'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/books/delete', methods=['POST'])
def delete_book():
    try:
        data = request.get_json()
        book_id = data.get('book_id')
        books = manager.display_all_books()
        before = len(books)
        if hasattr(manager, 'books'):
            manager.books = [b for b in manager.books if b.get('book_id') != book_id]
        else:
            from contextlib import suppress
            with suppress(Exception):
                cur = manager.connection.cursor()
                cur.execute('DELETE FROM books WHERE book_id = %s', (book_id,))
                manager.connection.commit()
        return jsonify({'success': True, 'message': 'Deleted'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/members', methods=['GET','POST'])
def members_endpoint():
    try:
        if request.method == 'GET':
            return jsonify(manager.display_all_members())
        data = request.get_json()
        manager.add_member(data.get('name'), data.get('email'), data.get('phone'), data.get('address'))
        return jsonify({'success': True, 'message': 'Member added'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/borrowings')
def borrowings_endpoint():
    try:
        return jsonify(manager.display_current_borrowings())
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/borrow', methods=['POST'])
def borrow():
    try:
        data = request.get_json()
        book_id = int(data.get('book_id'))
        member_id = int(data.get('member_id'))
        days = int(data.get('days', 14))
        ok, msg = manager.borrow_book(book_id, member_id, days) if hasattr(manager, 'borrow_book') else (False, 'Not supported')
        return jsonify({'success': ok, 'message': msg})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/return', methods=['POST'])
def ret():
    try:
        data = request.get_json()
        borrowing_id = int(data.get('borrowing_id'))
        ok = manager.return_book(borrowing_id)
        return jsonify({'success': bool(ok), 'message': 'Returned' if ok else 'Not found'})
    except Exception as e:
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500

# Serve lib.html and other static files
@app.route('/lib.html')
def serve_lib_html():
    return send_from_directory(os.path.dirname(__file__), 'lib.html')

@app.route('/<path:filename>')
def serve_static(filename):
    return send_from_directory(os.path.dirname(__file__), filename)

if __name__ == '__main__':
    print('Starting Flask server on http://127.0.0.1:5000')
    app.run(debug=True, host='127.0.0.1', port=5000)
